$(document).ready(function() {
    $("#accordion").accordion({
        event: "click",
        heightStyle: "content",
        collapsible: true
    });
});